export const PRODUCTS = [
    {
        _id: '122334567889',
        name: 'Nest Phone',
        price: 350,
        imgUrl: '',
    },
];